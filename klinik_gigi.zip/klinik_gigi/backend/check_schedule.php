<?php
header('Content-Type: application/json');

// Koneksi ke database dan logika pengecekan jadwal
$date = $_POST['date'];

// Simulasi pengecekan (ganti dengan logika database yang sebenarnya)
$appointmentsCount = 2; // Misalnya sudah ada 2 janji temu

if ($appointmentsCount < 3) {
    echo json_encode(['available' => true]);
} else {
    echo json_encode(['available' => false]);