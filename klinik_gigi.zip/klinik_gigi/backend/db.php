<?php
$servername = "localhost";
$username = "root";  // default username XAMPP
$password = "";      // default password XAMPP kosong
$dbname = "klinik_gigi";

$conn = new mysqli($servername, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>