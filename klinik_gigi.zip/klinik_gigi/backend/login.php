<?php
include 'db.php';

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM patients WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        header("Location: services.html");
    } else {
        echo "Password salah!";
    }
} else {
    echo "Akun tidak ditemukan!";
}

$conn->close();
?>
