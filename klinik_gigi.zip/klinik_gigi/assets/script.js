// Anda dapat menambahkan fungsionalitas JavaScript di sini jika diperlukan
// Contoh: validasi form di sisi klien

document.addEventListener('DOMContentLoaded', function() {
  const form = document.querySelector('form');
  form.addEventListener('submit', function(event) {
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;

      if (!email || !password) {
          event.preventDefault();
          alert('Harap isi semua field!');
      }
  });
});

document.addEventListener('DOMContentLoaded', function() {
  const form = document.querySelector('form');
  form.addEventListener('submit', function(event) {
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;

      if (!email || !password) {
          event.preventDefault();
          alert('Harap isi semua field!');
      } else if (password.length < 6) {
          event.preventDefault();
          alert('Password harus minimal 6 karakter!');
      }
  });
});